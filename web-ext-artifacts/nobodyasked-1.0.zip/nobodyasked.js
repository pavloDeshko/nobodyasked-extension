let el = document.querySelector('[data-initq]');
el && (el.style.display = "none")