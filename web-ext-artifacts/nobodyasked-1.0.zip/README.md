# NobodyAsked

**Removes People also asked section of Google search. Firefor Extension**


